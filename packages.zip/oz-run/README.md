# oz-run package

Automatically compile/run .oz/.ozf files and view result

![A screenshot of your package](https://raw.githubusercontent.com/ecuatox/oz-run/master/imgs/screenshot_hello_world.png)

## Hotkeys
* ctrl-alt-c: Compile (without save)
* ctrl-alt-r: Run compiled file
* ctrl-alt-g: Compile and run
* ctrl-alt-x: Clear output
* ctrl-alt-v: Insert default program
