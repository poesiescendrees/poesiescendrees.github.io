'use babel';

import OzRunView from '../lib/oz-run-view';

describe('OzRunView', () => {
  it('has one valid test', () => {
    expect('life').toBe('easy');
  });
});
