"""Helper module."""


def some_function(t):
    """Another silly function."""
    return t + " python"
