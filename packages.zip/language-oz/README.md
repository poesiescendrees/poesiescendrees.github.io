# Oz language support in Atom

Adds syntax highlighting to
[Oz](http://www.mozart-oz.org/) files in [Atom](https://atom.io/).

Originally [converted](http://atom.io/docs/latest/converting-a-text-mate-bundle)
from the [Oz TextMate bundle](https://github.com/eregon/oz-tmbundle).

Contributions are greatly appreciated. Please fork this repository and open a
pull request to add snippets, make grammar tweaks, etc.
