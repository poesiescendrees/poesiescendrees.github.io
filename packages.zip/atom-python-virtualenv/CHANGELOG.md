## 0.6.2
* Wrap filesystem watch in try catch with logging (#11)

## 0.6.1
* Support different versions of nodejs (#10)

## 0.6.0
* Track filesystem changes to virtualenvs (#5)

## 0.5.0 - Flexability
* Look for virtualenvwrapper when WORKON_HOME is not set (#7)
* Work without virtualenvwrapper using project local envs (#6)
* General menu improvements
* Removed context menu

## 0.4.0 - Environment management
* Create virtualenv (#1)
* Add deactivate functionality (#2)
* Improve command palette item names
* Add hot keys (#3)

## 0.3.0 - Menus!
* Added context menu
* Added application menu
* Fix functioning on linux systems (#4)

## 0.2.0 - Create environment management tool
* Limit virtualenv display to python file
* Update display on grammer change
* Allow selection of new environment

## 0.1.0 - First Release
* Show the selected virtualenv
