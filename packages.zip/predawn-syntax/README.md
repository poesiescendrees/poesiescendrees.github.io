# This is the syntax part of the Predawn theme for Atom. Meant to be paired with [Predawn-UI](https://github.com/jamiewilson/predawn-ui).

## Installation

Either, search for it in the Packages section in you Atom settings tab. Or from the command-line run:

```
apm install predawn-syntax
```

![Predawn syntax and UI](https://raw.githubusercontent.com/jamiewilson/predawn-syntax/master/predawn-atom.png)

View on Atom.io at http://atom.io/packages/predawn-syntax

## Sublime Text
[You can also find Predawn for Sublime Text here.](https://github.com/jamiewilson/predawn)
