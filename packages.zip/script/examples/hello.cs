// hello.cs
public class Hello1
{
	public static void Main()
  {
  	System.Console.WriteLine("Hello, World!");
	}
}
