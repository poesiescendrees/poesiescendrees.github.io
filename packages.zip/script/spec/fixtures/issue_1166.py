print ('汉语/漢語')
