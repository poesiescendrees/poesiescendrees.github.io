const path = require("path")
console.log("__dirname", path.resolve(__dirname))
