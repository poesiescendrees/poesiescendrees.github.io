// both datatip and linter tooltip below
function myfun(x: Function) {
  return x
}

myfun(() => console.log("hello world"))




// datatip below and linter tooltip above
function myfun2(x: Function) {
  return x
}
