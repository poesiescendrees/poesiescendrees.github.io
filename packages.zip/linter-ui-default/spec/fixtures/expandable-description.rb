# the descriptions are expandable (RuboCop)
def Myfun()
  return 1
end
