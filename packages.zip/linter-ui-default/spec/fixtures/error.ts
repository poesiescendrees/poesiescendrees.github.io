
// error and warning together
console.
