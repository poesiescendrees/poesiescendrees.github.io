module.exports = require('terser-config-atomic')
